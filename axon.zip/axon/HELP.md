# Getting Started

### Additional Links
These additional references should also help you:

* [The Axon Framework open-source code repository on GitHub](https://github.com/AxonFramework)
* [The reference guide on how to use Axon](https://docs.axoniq.io/reference-guide/)
* [A full getting started tutorial for Axon in small simple steps (YouTube).](https://www.youtube.com/watch?v=tqn9p8Duy54&list=PL4O1nDpoa5KQkkApGXjKi3rzUW3II5pjm)
* [The reference guide section on how to use Axon Test module](https://docs.axoniq.io/reference-guide/axon-framework/testing)

## Running in AxonIQ Cloud

* Get free access to a developer context at [cloud.axoniq.io](https://cloud.axoniq.io/)
* Create an application binding and paste the token in `src/main/resources/application.properties`
* [The blog post on how to use Axon Cloud Console](https://axoniq.io/blog-overview/how-to-use-axon-cloud-console)
