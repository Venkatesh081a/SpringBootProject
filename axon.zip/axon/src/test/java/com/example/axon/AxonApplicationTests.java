package com.example.axon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxonApplicationTests {

	@Test
	void contextLoads() {
	}

}
